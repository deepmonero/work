/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Button = ({ property1, className }) => {
  return (
    <div className={`BUTTON ${className}`}>
      {property1 === "default" && (
        <>
          <div className="before" />
          <div className="div" />
          <div className="before-2" />
          <div className="after" />
          <div className="after-2" />
        </>
      )}

      {property1 === "HOVER" && <img className="rectangle" alt="Rectangle" />}

      <div className="div-btn-primary">
        <div className="div-btn-primary-text">
          <div className={`BUY-snmt-NOW ${property1}`}>BUY $SNMT NOW</div>
        </div>
        <div className={`text-wrapper property-1-${property1}`}>↑</div>
      </div>
      {property1 === "default" && <div className="after-3" />}
    </div>
  );
};

Button.propTypes = {
  property1: PropTypes.oneOf(["HOVER", "default"]),
};
