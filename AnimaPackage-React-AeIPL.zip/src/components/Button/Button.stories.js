import { Button } from ".";

export default {
  title: "Components/Button",
  component: Button,
  argTypes: {
    property1: {
      options: ["HOVER", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "HOVER",
    className: {},
  },
};
