import { SocialIconsWrapper } from ".";

export default {
  title: "Components/SocialIconsWrapper",
  component: SocialIconsWrapper,
};

export const Default = {
  args: {
    className: {},
  },
};
