/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const PropertyDefaultWrapper = ({ property1, className, text = "BUY $SNMT NOW" }) => {
  return (
    <div className={`property-default-wrapper property-1-0-${property1} ${className}`}>
      {property1 === "default" && (
        <>
          <div className="before-3" />
          <div className="before-4" />
          <div className="before-5" />
          <div className="after-4" />
          <div className="after-5" />
          <div className="div-btn-primary-2">
            <div className="BUY-snmt-NOW-wrapper">
              <div className="BUY-snmt-NOW-2">{text}</div>
            </div>
            <div className="text-wrapper-2">↑</div>
          </div>
          <div className="after-6" />
        </>
      )}

      {property1 === "HOVER" && (
        <div className="overlap-group">
          <div className="div-btn-primary-3">
            <div className="BUY-snmt-NOW-wrapper">
              <div className="BUY-snmt-NOW-3">{text}</div>
            </div>
            <div className="text-wrapper-3">↑</div>
          </div>
        </div>
      )}
    </div>
  );
};

PropertyDefaultWrapper.propTypes = {
  property1: PropTypes.oneOf(["HOVER", "default"]),
  text: PropTypes.string,
};
