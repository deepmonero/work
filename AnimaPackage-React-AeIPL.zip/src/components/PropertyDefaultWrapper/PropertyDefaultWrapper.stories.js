import { PropertyDefaultWrapper } from ".";

export default {
  title: "Components/PropertyDefaultWrapper",
  component: PropertyDefaultWrapper,
  argTypes: {
    property1: {
      options: ["HOVER", "default"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "HOVER",
    className: {},
    text: "BUY $SNMT NOW",
  },
};
