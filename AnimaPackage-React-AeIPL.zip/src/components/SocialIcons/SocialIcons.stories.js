import { SocialIcons } from ".";

export default {
  title: "Components/SocialIcons",
  component: SocialIcons,
  argTypes: {
    platform: {
      options: [
        "twitch",
        "facebook",
        "telegram",
        "whats-app",
        "snapchat",
        "github",
        "tik-tok",
        "threads",
        "pinterest",
        "reddit",
        "dribbble",
        "google",
        "you-tube",
        "signal",
        "apple",
        "x-twitter",
        "messenger",
        "VK",
        "spotify",
        "figma",
        "tumblr",
        "linked-in",
        "instagram",
        "discord",
        "clubhouse",
        "medium",
      ],
      control: { type: "select" },
    },
    color: {
      options: ["negative", "original"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    platform: "twitch",
    color: "negative",
  },
};
