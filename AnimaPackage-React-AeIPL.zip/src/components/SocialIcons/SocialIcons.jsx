/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { PlatformAppleColorOriginal } from "../../icons/PlatformAppleColorOriginal";
import { PlatformClubhouseColorNegative } from "../../icons/PlatformClubhouseColorNegative";
import { PlatformClubhouseColorOriginal } from "../../icons/PlatformClubhouseColorOriginal";
import { PlatformDiscordColorNegative } from "../../icons/PlatformDiscordColorNegative";
import { PlatformDiscordColorOriginal } from "../../icons/PlatformDiscordColorOriginal";
import { PlatformDribbbleColorNegative } from "../../icons/PlatformDribbbleColorNegative";
import { PlatformDribbbleColorOriginal } from "../../icons/PlatformDribbbleColorOriginal";
import { PlatformFacebookColorNegative } from "../../icons/PlatformFacebookColorNegative";
import { PlatformFacebookColorOriginal } from "../../icons/PlatformFacebookColorOriginal";
import { PlatformFigmaColorNegative } from "../../icons/PlatformFigmaColorNegative";
import { PlatformFigmaColorOriginal } from "../../icons/PlatformFigmaColorOriginal";
import { PlatformGithubColorOriginal } from "../../icons/PlatformGithubColorOriginal";
import { PlatformGoogleColorNegative } from "../../icons/PlatformGoogleColorNegative";
import { PlatformInstagramColorNegative } from "../../icons/PlatformInstagramColorNegative";
import { PlatformLinkedinColorNegative } from "../../icons/PlatformLinkedinColorNegative";
import { PlatformLinkedinColorOriginal } from "../../icons/PlatformLinkedinColorOriginal";
import { PlatformMediumColorOriginal } from "../../icons/PlatformMediumColorOriginal";
import { PlatformMessengerColorNegative } from "../../icons/PlatformMessengerColorNegative";
import { PlatformMessengerColorOriginal } from "../../icons/PlatformMessengerColorOriginal";
import { PlatformPinterestColorNegative } from "../../icons/PlatformPinterestColorNegative";
import { PlatformPinterestColorOriginal } from "../../icons/PlatformPinterestColorOriginal";
import { PlatformRedditColorNegative } from "../../icons/PlatformRedditColorNegative";
import { PlatformRedditColorOriginal } from "../../icons/PlatformRedditColorOriginal";
import { PlatformSignalColorNegative } from "../../icons/PlatformSignalColorNegative";
import { PlatformSnapchatColorNegative } from "../../icons/PlatformSnapchatColorNegative";
import { PlatformSnapchatColorOriginal } from "../../icons/PlatformSnapchatColorOriginal";
import { PlatformSpotifyColorOriginal } from "../../icons/PlatformSpotifyColorOriginal";
import { PlatformTelegramColorNegative } from "../../icons/PlatformTelegramColorNegative";
import { PlatformTelegramColorOriginal } from "../../icons/PlatformTelegramColorOriginal";
import { PlatformThreadsColorNegative } from "../../icons/PlatformThreadsColorNegative";
import { PlatformTiktokColorNegative } from "../../icons/PlatformTiktokColorNegative";
import { PlatformTiktokColorOriginal } from "../../icons/PlatformTiktokColorOriginal";
import { PlatformTumblrColorOriginal } from "../../icons/PlatformTumblrColorOriginal";
import { PlatformTwitchColorNegative } from "../../icons/PlatformTwitchColorNegative";
import { PlatformTwitchColorOriginal } from "../../icons/PlatformTwitchColorOriginal";
import { PlatformVkColorNegative } from "../../icons/PlatformVkColorNegative";
import { PlatformVkColorOriginal } from "../../icons/PlatformVkColorOriginal";
import { PlatformWhatsappColorNegative } from "../../icons/PlatformWhatsappColorNegative";
import { PlatformXTwitterColorNegative } from "../../icons/PlatformXTwitterColorNegative";
import { PlatformYoutubeColorNegative } from "../../icons/PlatformYoutubeColorNegative";
import { PlatformYoutubeColorOriginal } from "../../icons/PlatformYoutubeColorOriginal";
import "./style.css";

export const SocialIcons = ({ platform, color }) => {
  return (
    <>
      {color === "negative" && platform === "messenger" && <PlatformMessengerColorNegative className="social-icons" />}

      {color === "negative" && platform === "twitch" && <PlatformTwitchColorNegative className="social-icons" />}

      {platform === "spotify" && (
        <PlatformSpotifyColorOriginal className="social-icons" color={color === "original" ? "#1ED760" : "white"} />
      )}

      {platform === "VK" && color === "negative" && <PlatformVkColorNegative className="social-icons" />}

      {platform === "signal" && (
        <PlatformSignalColorNegative className="social-icons" color={color === "original" ? "#3A76F0" : "white"} />
      )}

      {platform === "clubhouse" && color === "negative" && <PlatformClubhouseColorNegative className="social-icons" />}

      {color === "negative" && platform === "telegram" && <PlatformTelegramColorNegative className="social-icons" />}

      {platform === "tumblr" && (
        <PlatformTumblrColorOriginal className="social-icons" color={color === "original" ? "#001935" : "white"} />
      )}

      {platform === "tik-tok" && color === "negative" && <PlatformTiktokColorNegative className="social-icons" />}

      {color === "negative" && platform === "discord" && <PlatformDiscordColorNegative className="social-icons" />}

      {color === "negative" && platform === "reddit" && <PlatformRedditColorNegative className="social-icons" />}

      {color === "negative" && platform === "dribbble" && <PlatformDribbbleColorNegative className="social-icons" />}

      {color === "negative" && platform === "figma" && <PlatformFigmaColorNegative className="social-icons" />}

      {platform === "whats-app" && (
        <PlatformWhatsappColorNegative className="social-icons" color={color === "original" ? "#25D366" : "white"} />
      )}

      {platform === "threads" && (
        <PlatformThreadsColorNegative className="social-icons" color={color === "original" ? "black" : "white"} />
      )}

      {platform === "github" && (
        <PlatformGithubColorOriginal className="social-icons" color={color === "original" ? "#24292F" : "white"} />
      )}

      {platform === "medium" && (
        <PlatformMediumColorOriginal className="social-icons" color={color === "original" ? "black" : "white"} />
      )}

      {color === "negative" && platform === "pinterest" && <PlatformPinterestColorNegative className="social-icons" />}

      {platform === "snapchat" && color === "negative" && <PlatformSnapchatColorNegative className="social-icons" />}

      {platform === "apple" && (
        <PlatformAppleColorOriginal className="social-icons" color={color === "original" ? "black" : "white"} />
      )}

      {color === "negative" && platform === "you-tube" && <PlatformYoutubeColorNegative className="social-icons" />}

      {platform === "google" && color === "negative" && <PlatformGoogleColorNegative className="social-icons" />}

      {color === "negative" && platform === "linked-in" && <PlatformLinkedinColorNegative className="social-icons" />}

      {platform === "instagram" && color === "negative" && <PlatformInstagramColorNegative className="social-icons" />}

      {platform === "x-twitter" && (
        <PlatformXTwitterColorNegative className="social-icons" color={color === "original" ? "black" : "white"} />
      )}

      {color === "negative" && platform === "facebook" && <PlatformFacebookColorNegative className="social-icons" />}

      {color === "original" && platform === "messenger" && <PlatformMessengerColorOriginal className="social-icons" />}

      {color === "original" && platform === "twitch" && <PlatformTwitchColorOriginal className="social-icons" />}

      {color === "original" && platform === "VK" && <PlatformVkColorOriginal className="social-icons" />}

      {platform === "clubhouse" && color === "original" && <PlatformClubhouseColorOriginal className="social-icons" />}

      {color === "original" && platform === "telegram" && <PlatformTelegramColorOriginal className="social-icons" />}

      {platform === "tik-tok" && color === "original" && <PlatformTiktokColorOriginal className="social-icons" />}

      {color === "original" && platform === "discord" && <PlatformDiscordColorOriginal className="social-icons" />}

      {color === "original" && platform === "reddit" && <PlatformRedditColorOriginal className="social-icons" />}

      {color === "original" && platform === "dribbble" && <PlatformDribbbleColorOriginal className="social-icons" />}

      {color === "original" && platform === "figma" && <PlatformFigmaColorOriginal className="social-icons" />}

      {color === "original" && platform === "pinterest" && <PlatformPinterestColorOriginal className="social-icons" />}

      {platform === "snapchat" && color === "original" && <PlatformSnapchatColorOriginal className="social-icons" />}

      {color === "original" && platform === "you-tube" && <PlatformYoutubeColorOriginal className="social-icons" />}

      {color === "original" && ["google", "instagram"].includes(platform) && (
        <img
          className="social-icons"
          alt="Platform google"
          src={
            platform === "instagram"
              ? "/img/platform-instagram-color-original.png"
              : "/img/platform-google-color-original.png"
          }
        />
      )}

      {color === "original" && platform === "linked-in" && <PlatformLinkedinColorOriginal className="social-icons" />}

      {color === "original" && platform === "facebook" && <PlatformFacebookColorOriginal className="social-icons" />}
    </>
  );
};

SocialIcons.propTypes = {
  platform: PropTypes.oneOf([
    "twitch",
    "facebook",
    "telegram",
    "whats-app",
    "snapchat",
    "github",
    "tik-tok",
    "threads",
    "pinterest",
    "reddit",
    "dribbble",
    "google",
    "you-tube",
    "signal",
    "apple",
    "x-twitter",
    "messenger",
    "VK",
    "spotify",
    "figma",
    "tumblr",
    "linked-in",
    "instagram",
    "discord",
    "clubhouse",
    "medium",
  ]),
  color: PropTypes.oneOf(["negative", "original"]),
};
