export { PlatformInstagramColorNegative } from "./PlatformInstagramColorNegative";
