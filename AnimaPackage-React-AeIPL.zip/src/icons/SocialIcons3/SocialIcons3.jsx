/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const SocialIcons3 = ({ className }) => {
  return (
    <svg
      className={`social-icons-3 ${className}`}
      fill="none"
      height="25"
      viewBox="0 0 25 25"
      width="25"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_197_5)">
        <path
          className="path"
          d="M12.9217 24.0211C19.5491 24.0214 24.9219 18.6491 24.9223 12.0217C24.9226 5.39429 19.5503 0.0214393 12.9229 0.0211079C6.29543 0.0207765 0.922583 5.39309 0.922252 12.0205C0.92192 18.6479 6.29423 24.0208 12.9217 24.0211Z"
          fill="url(#paint0_linear_197_5)"
        />
        <path
          className="path"
          clipRule="evenodd"
          d="M6.35366 11.8945C9.85198 10.3705 12.1847 9.36585 13.3519 8.88044C16.6845 7.4945 17.377 7.25375 17.8284 7.24582C17.9276 7.24408 18.1496 7.26869 18.2934 7.38536C18.4148 7.48387 18.4481 7.61695 18.4641 7.71034C18.4801 7.80374 18.5 8.0165 18.4842 8.18274C18.3035 10.0802 17.5218 14.6849 17.1242 16.8101C16.9559 17.7093 16.6247 18.0108 16.304 18.0403C15.6072 18.1044 15.078 17.5797 14.4031 17.1372C13.347 16.4449 12.7504 16.0138 11.7252 15.3382C10.5405 14.5574 11.3085 14.1283 11.9838 13.4271C12.1605 13.2436 15.231 10.451 15.2905 10.1976C15.2979 10.1659 15.3048 10.0478 15.2346 9.98545C15.1645 9.92308 15.0609 9.94441 14.9862 9.96136C14.8802 9.9854 13.193 11.1005 9.92433 13.3067C9.44541 13.6355 9.01161 13.7957 8.62296 13.7873C8.1945 13.778 7.37032 13.545 6.75763 13.3458C6.00614 13.1015 5.40887 12.9723 5.4609 12.5574C5.488 12.3413 5.78559 12.1204 6.35366 11.8945Z"
          fill="white"
          fillRule="evenodd"
        />
      </g>
      <defs className="defs">
        <linearGradient
          className="linear-gradient"
          gradientUnits="userSpaceOnUse"
          id="paint0_linear_197_5"
          x1="12.9229"
          x2="12.9217"
          y1="0.0211079"
          y2="23.8431"
        >
          <stop className="stop" stopColor="#2AABEE" />
          <stop className="stop" offset="1" stopColor="#229ED9" />
        </linearGradient>
        <clipPath className="clip-path" id="clip0_197_5">
          <rect className="rect" fill="white" height="24" transform="translate(0.922852 0.0205078)" width="24" />
        </clipPath>
      </defs>
    </svg>
  );
};
