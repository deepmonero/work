export { PlatformDiscordColorOriginal } from "./PlatformDiscordColorOriginal";
