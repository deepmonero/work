export { PlatformTiktokColorOriginal } from "./PlatformTiktokColorOriginal";
