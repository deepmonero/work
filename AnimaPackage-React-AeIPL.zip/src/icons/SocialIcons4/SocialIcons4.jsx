/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const SocialIcons4 = ({ color = "url(#paint0_linear_197_35)", className }) => {
  return (
    <svg
      className={`social-icons-4 ${className}`}
      fill="none"
      height="36"
      viewBox="0 0 36 36"
      width="36"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_107_1000)">
        <path
          className="path"
          d="M18 36C27.9411 36 36 27.9411 36 18C36 8.05887 27.9411 0 18 0C8.05887 0 0 8.05887 0 18C0 27.9411 8.05887 36 18 36Z"
          fill={color}
        />
        <path
          className="path"
          clipRule="evenodd"
          d="M8.14753 17.8099C13.3949 15.5237 16.894 14.0165 18.6447 13.2883C23.6435 11.2092 24.6822 10.848 25.3592 10.8361C25.5081 10.8334 25.8411 10.8703 26.0567 11.0453C26.2388 11.1931 26.2889 11.3927 26.3129 11.5328C26.3369 11.6729 26.3668 11.992 26.343 12.2414C26.0721 15.0876 24.9 21.9946 24.3037 25.1825C24.0514 26.5314 23.5546 26.9836 23.0736 27.0279C22.0283 27.1241 21.2345 26.3371 20.2221 25.6734C18.6379 24.6349 17.7429 23.9885 16.2051 22.9751C14.428 21.804 15.58 21.1603 16.5928 20.1084C16.8579 19.8331 21.4635 15.644 21.5526 15.2639C21.5637 15.2164 21.5741 15.0393 21.4688 14.9457C21.3636 14.8522 21.2083 14.8841 21.0962 14.9096C20.9373 14.9457 18.4064 16.6184 13.5037 19.9279C12.7853 20.4212 12.1346 20.6616 11.5516 20.649C10.9089 20.6351 9.67265 20.2856 8.7536 19.9868C7.62635 19.6204 6.73043 19.4267 6.80845 18.8044C6.84908 18.4803 7.29544 18.1488 8.14753 17.8099Z"
          fill="white"
          fillRule="evenodd"
        />
      </g>
      <defs className="defs">
        <linearGradient
          className="linear-gradient"
          gradientUnits="userSpaceOnUse"
          id="paint0_linear_107_1000"
          x1="18"
          x2="18"
          y1="0"
          y2="35.733"
        >
          <stop className="stop" stopColor="#2AABEE" />
          <stop className="stop" offset="1" stopColor="#229ED9" />
        </linearGradient>
        <clipPath className="clip-path" id="clip0_107_1000">
          <rect className="rect" fill="white" height="36" width="36" />
        </clipPath>
      </defs>
    </svg>
  );
};

SocialIcons4.propTypes = {
  color: PropTypes.string,
};
