export { PlatformTiktokColorNegative } from "./PlatformTiktokColorNegative";
