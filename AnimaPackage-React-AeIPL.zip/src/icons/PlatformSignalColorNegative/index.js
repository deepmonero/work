export { PlatformSignalColorNegative } from "./PlatformSignalColorNegative";
