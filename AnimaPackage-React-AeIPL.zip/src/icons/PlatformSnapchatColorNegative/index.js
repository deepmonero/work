export { PlatformSnapchatColorNegative } from "./PlatformSnapchatColorNegative";
