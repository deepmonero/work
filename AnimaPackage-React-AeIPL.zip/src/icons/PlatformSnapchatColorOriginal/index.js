export { PlatformSnapchatColorOriginal } from "./PlatformSnapchatColorOriginal";
