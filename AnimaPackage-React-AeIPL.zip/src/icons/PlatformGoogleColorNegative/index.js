export { PlatformGoogleColorNegative } from "./PlatformGoogleColorNegative";
