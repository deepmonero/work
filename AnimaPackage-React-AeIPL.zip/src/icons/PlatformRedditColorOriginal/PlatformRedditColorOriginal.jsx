/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const PlatformRedditColorOriginal = ({ className }) => {
  return (
    <svg
      className={`platform-reddit-color-original ${className}`}
      fill="none"
      height="48"
      viewBox="0 0 48 48"
      width="48"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g className="g" clipPath="url(#clip0_32_5715)">
        <path
          className="path"
          d="M24 0C10.7456 0 0 10.7456 0 24C0 30.6281 2.68688 36.6281 7.02938 40.9706L2.45812 45.5419C1.55062 46.4494 2.19375 48 3.47625 48H24C37.2544 48 48 37.2544 48 24C48 10.7456 37.2544 0 24 0Z"
          fill="#FF4500"
        />
        <path
          className="path"
          d="M37.605 28.7887C40.7002 28.7887 43.2094 26.2796 43.2094 23.1844C43.2094 20.0892 40.7002 17.58 37.605 17.58C34.5098 17.58 32.0006 20.0892 32.0006 23.1844C32.0006 26.2796 34.5098 28.7887 37.605 28.7887Z"
          fill="url(#paint0_radial_32_5715)"
        />
        <path
          className="path"
          d="M10.395 28.7887C13.4902 28.7887 15.9994 26.2796 15.9994 23.1844C15.9994 20.0892 13.4902 17.58 10.395 17.58C7.29978 17.58 4.79062 20.0892 4.79062 23.1844C4.79062 26.2796 7.29978 28.7887 10.395 28.7887Z"
          fill="url(#paint1_radial_32_5715)"
        />
        <path
          className="path"
          d="M24.0131 39.9994C32.8493 39.9994 40.0125 34.6268 40.0125 27.9994C40.0125 21.372 32.8493 15.9994 24.0131 15.9994C15.1769 15.9994 8.01376 21.372 8.01376 27.9994C8.01376 34.6268 15.1769 39.9994 24.0131 39.9994Z"
          fill="url(#paint2_radial_32_5715)"
        />
        <path
          className="path"
          d="M19.2825 26.8331C19.1888 28.8656 17.8388 29.6044 16.2694 29.6044C14.7 29.6044 13.5 28.5637 13.5938 26.5312C13.6875 24.4987 15.0375 23.1525 16.6069 23.1525C18.1763 23.1525 19.3763 24.8006 19.2825 26.8331Z"
          fill="#842123"
        />
        <path
          className="path"
          d="M34.4325 26.5294C34.5263 28.5619 33.3281 29.6025 31.7569 29.6025C30.1856 29.6025 28.8356 28.8656 28.7438 26.8313C28.65 24.7988 29.8481 23.1506 31.4194 23.1506C32.9906 23.1506 34.3406 24.495 34.4325 26.5294Z"
          fill="#842123"
        />
        <path
          className="path"
          d="M28.7438 27.0094C28.8319 28.9125 30.0937 29.6025 31.5637 29.6025C33.0337 29.6025 34.155 28.5694 34.0669 26.6663C33.9788 24.7631 32.7169 23.5181 31.2469 23.5181C29.7769 23.5181 28.6556 25.1063 28.7438 27.0094Z"
          fill="url(#paint3_radial_32_5715)"
        />
        <path
          className="path"
          d="M19.2844 27.0094C19.1962 28.9125 17.9344 29.6025 16.4644 29.6025C14.9944 29.6025 13.8731 28.5694 13.9612 26.6663C14.0494 24.7631 15.3112 23.5181 16.7812 23.5181C18.2512 23.5181 19.3725 25.1063 19.2844 27.0094Z"
          fill="url(#paint4_radial_32_5715)"
        />
        <path
          className="path"
          d="M24.0131 30.96C22.0294 30.96 20.1281 31.0556 18.3694 31.23C18.0694 31.26 17.8781 31.5656 17.9944 31.8394C18.9787 34.1475 21.3019 35.7694 24.0131 35.7694C26.7244 35.7694 29.0456 34.1475 30.0319 31.8394C30.1481 31.5656 29.9587 31.26 29.6569 31.23C27.8981 31.0556 25.9969 30.96 24.0131 30.96Z"
          fill="#BBCFDA"
        />
        <path
          className="path"
          d="M24.0131 31.4006C22.035 31.4006 20.1394 31.4981 18.3863 31.6763C18.0863 31.7063 17.8969 32.0175 18.0131 32.295C18.9956 34.6406 21.3113 36.2869 24.0113 36.2869C26.7113 36.2869 29.0288 34.6388 30.0113 32.295C30.1275 32.0175 29.9381 31.7063 29.6381 31.6763C27.885 31.4981 25.9894 31.4006 24.0113 31.4006H24.0131Z"
          fill="white"
        />
        <path
          className="path"
          d="M24.0131 31.1719C22.0669 31.1719 20.2012 31.2675 18.4744 31.4419C18.18 31.4719 17.9925 31.7775 18.1069 32.0513C19.0725 34.3594 21.3525 35.9812 24.0131 35.9812C26.6737 35.9812 28.9519 34.3594 29.9194 32.0513C30.0337 31.7775 29.8462 31.4719 29.5519 31.4419C27.8269 31.2675 25.9612 31.1719 24.0131 31.1719Z"
          fill="url(#paint5_radial_32_5715)"
        />
        <path
          className="path"
          d="M32.7769 14.3681C34.9701 14.3681 36.7481 12.5901 36.7481 10.3969C36.7481 8.20362 34.9701 6.42563 32.7769 6.42563C30.5836 6.42563 28.8056 8.20362 28.8056 10.3969C28.8056 12.5901 30.5836 14.3681 32.7769 14.3681Z"
          fill="url(#paint6_radial_32_5715)"
        />
        <path
          className="path"
          d="M23.9569 16.5056C23.4806 16.5056 23.0963 16.3069 23.0963 15.9994C23.0963 12.4406 25.9913 9.54749 29.5481 9.54749C30.0244 9.54749 30.4088 9.93374 30.4088 10.4081C30.4088 10.8825 30.0225 11.2687 29.5481 11.2687C26.94 11.2687 24.8175 13.3912 24.8175 15.9994C24.8175 16.3069 24.4313 16.5056 23.9569 16.5056Z"
          fill="url(#paint7_radial_32_5715)"
        />
        <path
          className="path"
          d="M18.2381 27.9506C18.2381 28.6875 17.4544 29.0175 16.4888 29.0175C15.5231 29.0175 14.7394 28.6875 14.7394 27.9506C14.7394 27.2137 15.5231 26.6175 16.4888 26.6175C17.4544 26.6175 18.2381 27.2137 18.2381 27.9506Z"
          fill="#FF6101"
        />
        <path
          className="path"
          d="M33.2888 27.9506C33.2888 28.6875 32.505 29.0175 31.5394 29.0175C30.5738 29.0175 29.79 28.6875 29.79 27.9506C29.79 27.2137 30.5738 26.6175 31.5394 26.6175C32.505 26.6175 33.2888 27.2137 33.2888 27.9506Z"
          fill="#FF6101"
        />
        <path
          className="path"
          d="M17.6963 25.9519C18.0401 25.9519 18.3188 25.648 18.3188 25.2731C18.3188 24.8982 18.0401 24.5944 17.6963 24.5944C17.3525 24.5944 17.0738 24.8982 17.0738 25.2731C17.0738 25.648 17.3525 25.9519 17.6963 25.9519Z"
          fill="#FFC49C"
        />
        <path
          className="path"
          d="M32.4919 25.9519C32.8357 25.9519 33.1144 25.648 33.1144 25.2731C33.1144 24.8982 32.8357 24.5944 32.4919 24.5944C32.1481 24.5944 31.8694 24.8982 31.8694 25.2731C31.8694 25.648 32.1481 25.9519 32.4919 25.9519Z"
          fill="#FFC49C"
        />
      </g>
      <defs className="defs">
        <radialGradient
          className="radial-gradient"
          cx="0"
          cy="0"
          gradientTransform="translate(37.6897 20.167) scale(11.2315 9.79772)"
          gradientUnits="userSpaceOnUse"
          id="paint0_radial_32_5715"
          r="1"
        >
          <stop className="stop" stopColor="#FEFFFF" />
          <stop className="stop" offset="0.4" stopColor="#FEFFFF" />
          <stop className="stop" offset="0.51" stopColor="#F9FCFC" />
          <stop className="stop" offset="0.62" stopColor="#EDF3F5" />
          <stop className="stop" offset="0.7" stopColor="#DEE9EC" />
          <stop className="stop" offset="0.72" stopColor="#D8E4E8" />
          <stop className="stop" offset="0.76" stopColor="#CCD8DF" />
          <stop className="stop" offset="0.8" stopColor="#C8D5DD" />
          <stop className="stop" offset="0.83" stopColor="#CCD6DE" />
          <stop className="stop" offset="0.85" stopColor="#D8DBE2" />
          <stop className="stop" offset="0.88" stopColor="#EDE3E9" />
          <stop className="stop" offset="0.9" stopColor="#FFEBEF" />
        </radialGradient>
        <radialGradient
          className="radial-gradient"
          cx="0"
          cy="0"
          gradientTransform="translate(10.4797 20.167) scale(11.2315 9.79772)"
          gradientUnits="userSpaceOnUse"
          id="paint1_radial_32_5715"
          r="1"
        >
          <stop className="stop" stopColor="#FEFFFF" />
          <stop className="stop" offset="0.4" stopColor="#FEFFFF" />
          <stop className="stop" offset="0.51" stopColor="#F9FCFC" />
          <stop className="stop" offset="0.62" stopColor="#EDF3F5" />
          <stop className="stop" offset="0.7" stopColor="#DEE9EC" />
          <stop className="stop" offset="0.72" stopColor="#D8E4E8" />
          <stop className="stop" offset="0.76" stopColor="#CCD8DF" />
          <stop className="stop" offset="0.8" stopColor="#C8D5DD" />
          <stop className="stop" offset="0.83" stopColor="#CCD6DE" />
          <stop className="stop" offset="0.85" stopColor="#D8DBE2" />
          <stop className="stop" offset="0.88" stopColor="#EDE3E9" />
          <stop className="stop" offset="0.9" stopColor="#FFEBEF" />
        </radialGradient>
        <radialGradient
          className="radial-gradient"
          cx="0"
          cy="0"
          gradientTransform="translate(24.4401 18.5955) scale(33.8788 23.7872)"
          gradientUnits="userSpaceOnUse"
          id="paint2_radial_32_5715"
          r="1"
        >
          <stop className="stop" stopColor="#FEFFFF" />
          <stop className="stop" offset="0.4" stopColor="#FEFFFF" />
          <stop className="stop" offset="0.51" stopColor="#F9FCFC" />
          <stop className="stop" offset="0.62" stopColor="#EDF3F5" />
          <stop className="stop" offset="0.7" stopColor="#DEE9EC" />
          <stop className="stop" offset="0.72" stopColor="#D8E4E8" />
          <stop className="stop" offset="0.76" stopColor="#CCD8DF" />
          <stop className="stop" offset="0.8" stopColor="#C8D5DD" />
          <stop className="stop" offset="0.83" stopColor="#CCD6DE" />
          <stop className="stop" offset="0.85" stopColor="#D8DBE2" />
          <stop className="stop" offset="0.88" stopColor="#EDE3E9" />
          <stop className="stop" offset="0.9" stopColor="#FFEBEF" />
        </radialGradient>
        <radialGradient
          className="radial-gradient"
          cx="0"
          cy="0"
          gradientTransform="translate(30.99 28.3071) rotate(180) scale(2.83057 4.15553)"
          gradientUnits="userSpaceOnUse"
          id="paint3_radial_32_5715"
          r="1"
        >
          <stop className="stop" stopColor="#FF6600" />
          <stop className="stop" offset="0.5" stopColor="#FF4500" />
          <stop className="stop" offset="0.7" stopColor="#FC4301" />
          <stop className="stop" offset="0.82" stopColor="#F43F07" />
          <stop className="stop" offset="0.92" stopColor="#E53812" />
          <stop className="stop" offset="1" stopColor="#D4301F" />
        </radialGradient>
        <radialGradient
          className="radial-gradient"
          cx="0"
          cy="0"
          gradientTransform="translate(16.9107 28.3071) scale(2.83057 4.15553)"
          gradientUnits="userSpaceOnUse"
          id="paint4_radial_32_5715"
          r="1"
        >
          <stop className="stop" stopColor="#FF6600" />
          <stop className="stop" offset="0.5" stopColor="#FF4500" />
          <stop className="stop" offset="0.7" stopColor="#FC4301" />
          <stop className="stop" offset="0.82" stopColor="#F43F07" />
          <stop className="stop" offset="0.92" stopColor="#E53812" />
          <stop className="stop" offset="1" stopColor="#D4301F" />
        </radialGradient>
        <radialGradient
          className="radial-gradient"
          cx="0"
          cy="0"
          gradientTransform="translate(24.0691 36.5452) scale(9.98104 6.58324)"
          gradientUnits="userSpaceOnUse"
          id="paint5_radial_32_5715"
          r="1"
        >
          <stop className="stop" stopColor="#172E35" />
          <stop className="stop" offset="0.29" stopColor="#0E1C21" />
          <stop className="stop" offset="0.73" stopColor="#030708" />
          <stop className="stop" offset="1" />
        </radialGradient>
        <radialGradient
          className="radial-gradient"
          cx="0"
          cy="0"
          gradientTransform="translate(32.871 6.3949) scale(8.76139 8.76139)"
          gradientUnits="userSpaceOnUse"
          id="paint6_radial_32_5715"
          r="1"
        >
          <stop className="stop" stopColor="#FEFFFF" />
          <stop className="stop" offset="0.4" stopColor="#FEFFFF" />
          <stop className="stop" offset="0.51" stopColor="#F9FCFC" />
          <stop className="stop" offset="0.62" stopColor="#EDF3F5" />
          <stop className="stop" offset="0.7" stopColor="#DEE9EC" />
          <stop className="stop" offset="0.72" stopColor="#D8E4E8" />
          <stop className="stop" offset="0.76" stopColor="#CCD8DF" />
          <stop className="stop" offset="0.8" stopColor="#C8D5DD" />
          <stop className="stop" offset="0.83" stopColor="#CCD6DE" />
          <stop className="stop" offset="0.85" stopColor="#D8DBE2" />
          <stop className="stop" offset="0.88" stopColor="#EDE3E9" />
          <stop className="stop" offset="0.9" stopColor="#FFEBEF" />
        </radialGradient>
        <radialGradient
          className="radial-gradient"
          cx="0"
          cy="0"
          gradientTransform="translate(29.22 15.9461) scale(7.1813 7.18131)"
          gradientUnits="userSpaceOnUse"
          id="paint7_radial_32_5715"
          r="1"
        >
          <stop className="stop" offset="0.48" stopColor="#7A9299" />
          <stop className="stop" offset="0.67" stopColor="#172E35" />
          <stop className="stop" offset="0.75" />
          <stop className="stop" offset="0.82" stopColor="#172E35" />
        </radialGradient>
        <clipPath className="clip-path" id="clip0_32_5715">
          <rect className="rect" fill="white" height="48" width="48" />
        </clipPath>
      </defs>
    </svg>
  );
};
