export { PlatformFacebookColorOriginal } from "./PlatformFacebookColorOriginal";
