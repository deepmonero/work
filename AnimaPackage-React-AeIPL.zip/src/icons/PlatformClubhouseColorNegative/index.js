export { PlatformClubhouseColorNegative } from "./PlatformClubhouseColorNegative";
