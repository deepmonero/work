export { PlatformWhatsappColorNegative } from "./PlatformWhatsappColorNegative";
