export { PlatformXTwitterColorNegative } from "./PlatformXTwitterColorNegative";
