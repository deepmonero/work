export { PlatformTelegramColorOriginal } from "./PlatformTelegramColorOriginal";
