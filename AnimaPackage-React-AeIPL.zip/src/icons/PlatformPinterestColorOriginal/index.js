export { PlatformPinterestColorOriginal } from "./PlatformPinterestColorOriginal";
