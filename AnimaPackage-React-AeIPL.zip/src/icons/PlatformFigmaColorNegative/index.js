export { PlatformFigmaColorNegative } from "./PlatformFigmaColorNegative";
