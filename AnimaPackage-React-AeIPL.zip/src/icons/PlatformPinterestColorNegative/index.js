export { PlatformPinterestColorNegative } from "./PlatformPinterestColorNegative";
