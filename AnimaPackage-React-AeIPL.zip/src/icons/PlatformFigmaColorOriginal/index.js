export { PlatformFigmaColorOriginal } from "./PlatformFigmaColorOriginal";
