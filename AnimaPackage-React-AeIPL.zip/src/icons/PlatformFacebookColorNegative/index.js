export { PlatformFacebookColorNegative } from "./PlatformFacebookColorNegative";
