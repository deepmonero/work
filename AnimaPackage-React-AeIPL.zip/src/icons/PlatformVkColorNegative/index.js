export { PlatformVkColorNegative } from "./PlatformVkColorNegative";
