export { PlatformMediumColorOriginal } from "./PlatformMediumColorOriginal";
