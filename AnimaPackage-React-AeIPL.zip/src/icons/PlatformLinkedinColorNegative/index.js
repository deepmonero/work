export { PlatformLinkedinColorNegative } from "./PlatformLinkedinColorNegative";
