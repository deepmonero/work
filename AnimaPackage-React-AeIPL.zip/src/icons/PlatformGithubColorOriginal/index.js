export { PlatformGithubColorOriginal } from "./PlatformGithubColorOriginal";
