export { PlatformSpotifyColorOriginal } from "./PlatformSpotifyColorOriginal";
