export { PlatformTelegramColorNegative } from "./PlatformTelegramColorNegative";
