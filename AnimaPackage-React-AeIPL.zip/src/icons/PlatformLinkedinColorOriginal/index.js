export { PlatformLinkedinColorOriginal } from "./PlatformLinkedinColorOriginal";
