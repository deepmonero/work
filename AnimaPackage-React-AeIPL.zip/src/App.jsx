import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Q } from "./screens/Q";
import { IphoneProMax } from "./screens/IphoneProMax";
import { QScreen } from "./screens/QScreen";
import { QWrapper } from "./screens/QWrapper";
import { DivWrapper } from "./screens/DivWrapper";

const router = createBrowserRouter([
  {
    path: "/*",
    element: <Q />,
  },
  {
    path: "/q5",
    element: <Q />,
  },
  {
    path: "/iphone-14-u38-15-pro-max-1-all-breakpoints",
    element: <IphoneProMax />,
  },
  {
    path: "/q4",
    element: <QScreen />,
  },
  {
    path: "/q2",
    element: <QWrapper />,
  },
  {
    path: "/q3",
    element: <DivWrapper />,
  },
]);

export const App = () => {
  return <RouterProvider router={router} />;
};
