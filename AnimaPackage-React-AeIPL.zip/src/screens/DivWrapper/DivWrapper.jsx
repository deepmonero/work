import React from "react";
import "./style.css";

export const DivWrapper = () => {
  return (
    <div className="div-wrapper">
      <div className="q-16">
        <div className="div-20">
          <img className="component-8" alt="Component" src="/img/component-1-7.svg" />
          <div className="how-do-you-work-6">
            <p className="text-wrapper-73">How do you buy BRC-20 tokens?</p>
          </div>
        </div>
        <div className="div-21" />
        <p className="text-wrapper-74">
          Some popular BRC-20 tokens can be bought on centralized exchanges, while others – through www.unisat.io
        </p>
      </div>
    </div>
  );
};
