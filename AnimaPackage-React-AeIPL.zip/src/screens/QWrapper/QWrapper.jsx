import React from "react";
import "./style.css";

export const QWrapper = () => {
  return (
    <div className="q-wrapper">
      <div className="q-15">
        <div className="div-18">
          <img className="component-7" alt="Component" src="/img/component-1-6.svg" />
          <div className="how-do-you-work-5">
            <div className="text-wrapper-71">What are BRC-20 tokens?</div>
          </div>
        </div>
        <div className="div-19" />
        <p className="text-wrapper-72">BRC-20 tokens are built on the Bitcoin Network using the ordinals protocol.</p>
      </div>
    </div>
  );
};
