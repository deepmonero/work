import React from "react";
import "./style.css";

export const Q = () => {
  return (
    <div className="q">
      <div className="div-2">
        <div className="div-3">
          <img className="component" alt="Component" src="/img/component-1-4.svg" />
          <div className="how-do-you-work">
            <p className="p">What’s the difference between BRC-20 and ERC-20 tokens?</p>
          </div>
        </div>
        <p className="text-wrapper-4">
          The ERC-20 tokens are built on the Ethereum network and follow the ERC-20 token standard deployed using smart
          contracts. On the other hand, BRC-20 tokens are built on the Bitcoin blockchain and follow the BRC-20 token
          standard without the need for smart contracts.
        </p>
      </div>
    </div>
  );
};
