import React from "react";
import "./style.css";

export const QScreen = () => {
  return (
    <div className="q-screen">
      <div className="q-14">
        <div className="div-16">
          <img className="component-6" alt="Component" src="/img/component-1-5.svg" />
          <div className="how-do-you-work-4">
            <p className="text-wrapper-69">How are BRC-20 tokens created?</p>
          </div>
        </div>
        <div className="div-17" />
        <p className="text-wrapper-70">
          These tokens are created using JavaScript Object Notion to make ordinal inscriptions on Satoshis, thereby
          creating tokens with equal value.
        </p>
      </div>
    </div>
  );
};
