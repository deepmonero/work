export { QScreen } from "./QScreen";
