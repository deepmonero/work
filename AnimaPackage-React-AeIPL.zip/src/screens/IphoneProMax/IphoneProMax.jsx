import React from "react";
import { Link } from "react-router-dom";
import { useWindowWidth } from "../../breakpoints";
import { Button } from "../../components/Button";
import { PropertyDefaultWrapper } from "../../components/PropertyDefaultWrapper";
import { SocialIcons } from "../../components/SocialIcons";
import { SocialIconsWrapper } from "../../components/SocialIconsWrapper";
import { SocialIcons3 } from "../../icons/SocialIcons3";
import "./style.css";

export const IphoneProMax = () => {
  const screenWidth = useWindowWidth();

  return (
    <div className="iphone-pro-max">
      <div
        className="div-4"
        style={{
          height: screenWidth < 1440 ? "4775.02px" : screenWidth >= 1440 ? "5412px" : undefined,
          width: screenWidth < 1440 ? "430.24px" : screenWidth >= 1440 ? "1440px" : undefined,
        }}
      >
        {screenWidth < 1440 && (
          <header className="header">
            <div className="frame">
              <SocialIcons color="negative" platform="x-twitter" />
              <div className="social-icons-3-wrapper">
                <SocialIcons3 className="social-icons-3" />
              </div>
            </div>
            <div className="coin">
              <div className="overlap">
                <div className="group">
                  <div className="overlap-group-2">
                    <img className="ellipse" alt="Ellipse" src="/img/ellipse-8.png" />
                    <img className="img" alt="Ellipse" src="/img/ellipse-1.png" />
                  </div>
                  <div className="overlap-2">
                    <img className="ellipse-2" alt="Ellipse" src="/img/ellipse-2.svg" />
                    <img className="ellipse-3" alt="Ellipse" src="/img/ellipse-6.svg" />
                    <img className="ellipse-4" alt="Ellipse" src="/img/ellipse-3.svg" />
                  </div>
                </div>
                <img className="yellow" alt="Yellow" src="/img/yellow-2x.png" />
              </div>
            </div>
          </header>
        )}

        <div
          className="hero"
          style={{
            height: screenWidth < 1440 ? "685px" : screenWidth >= 1440 ? "1303px" : undefined,
            left: screenWidth < 1440 ? "-38px" : screenWidth >= 1440 ? "0" : undefined,
            top: screenWidth < 1440 ? "73px" : screenWidth >= 1440 ? "5px" : undefined,
            width: screenWidth < 1440 ? "505px" : screenWidth >= 1440 ? "1463px" : undefined,
          }}
        >
          {screenWidth < 1440 && (
            <div className="overlap-3">
              <img className="group-2" alt="Group" src="/img/group-13603-3.png" />
              <div className="frame-2">
                <div className="HERO-TEXT">
                  <img
                    className="step-into-the-SNMT"
                    alt="Step into the SNMT"
                    src="/img/step-into-the-snmt-meme-central.svg"
                  />
                  <p className="text-wrapper-5">
                    where the magic of Satoshi Nakamoto Token (SNMT) meets the world of laughter and blockchain. Unleash
                    the power of humor with our meme token dedicated to the enigmatic creator of Bitcoin.
                  </p>
                </div>
                <div className="BUTTON-2">
                  <div className="before-6" />
                  <div className="before-7" />
                  <div className="before-8" />
                  <div className="after-7" />
                  <div className="div-btn-primary-4">
                    <div className="div-btn-primary-text-2">
                      <div className="BUY-snmt-NOW-4">BUY $SNMT NOW</div>
                    </div>
                    <div className="text-wrapper-6">↑</div>
                    <div className="after-8" />
                  </div>
                  <div className="after-9" />
                </div>
              </div>
            </div>
          )}

          {screenWidth >= 1440 && (
            <>
              <div className="header-2">
                <div className="overlap-4">
                  <div className="div-header-container-wrapper">
                    <div className="div-header-container">
                      <div className="div-vertical-line" />
                      <div className="div-header-side-part">
                        <div className="link-home">
                          <div className="overlap-wrapper">
                            <div className="overlap-5">
                              <div className="group-3">
                                <div className="overlap-group-3">
                                  <img className="ellipse-5" alt="Ellipse" src="/img/rectangle-1-2x.png" />
                                  <img className="ellipse-6" alt="Ellipse" src="/img/ellipse-1-1.png" />
                                </div>
                                <div className="overlap-6">
                                  <img className="ellipse-7" alt="Ellipse" src="/img/ellipse-2-1.svg" />
                                  <img className="ellipse-8" alt="Ellipse" src="/img/ellipse-6-1.svg" />
                                  <img className="ellipse-9" alt="Ellipse" src="/img/ellipse-3-1.svg" />
                                </div>
                              </div>
                              <img className="yellow-2" alt="Yellow" src="/img/yellow.png" />
                            </div>
                          </div>
                          <div className="text-wrapper-7">Satoshi Tokens</div>
                        </div>
                      </div>
                      <div className="div-vertical-line-2" />
                    </div>
                  </div>
                  <SocialIcons color="negative" platform="x-twitter" />
                </div>
                <div className="frame-3">
                  <div className="HERO-TEXT-2">
                    <img
                      className="step-into-the-SNMT-2"
                      alt="Step into the SNMT"
                      src="/img/step-into-the-snmt-meme-central-1.svg"
                    />
                    <p className="text-wrapper-8">
                      where the magic of Satoshi Nakamoto Token (SNMT) meets the world of laughter and blockchain.
                      Unleash the power of humor with our meme token dedicated to the enigmatic creator of Bitcoin.
                    </p>
                  </div>
                  <div className="BUTTON-2">
                    <div className="before-6" />
                    <div className="before-7" />
                    <div className="before-8" />
                    <div className="after-7" />
                    <div className="div-btn-primary-4">
                      <div className="div-btn-primary-text-2">
                        <div className="BUY-snmt-NOW-4">BUY $SNMT NOW</div>
                      </div>
                      <div className="text-wrapper-6">↑</div>
                      <div className="after-8" />
                    </div>
                    <div className="after-9" />
                  </div>
                </div>
              </div>
              <div className="ABOUT">
                <div className="overlap-7">
                  <div className="scroll">
                    <div className="bottom-left">
                      <div className="text-wrapper-9">KNOW MORE</div>
                      <div className="highlight">
                        <div className="heading">
                          <div className="details">
                            <div className="heading-2">
                              <div className="text-wrapper-10">ABOUT US</div>
                            </div>
                            <img className="SVG" alt="Svg" src="/img/svg-1.svg" />
                            <div className="line" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="bottom-right">
                      <div className="link">
                        <div className="scroll-2">
                          <div className="text">
                            <div className="text-wrapper-11">SCROLL</div>
                          </div>
                        </div>
                        <img className="button" alt="Button" src="/img/button-1.svg" />
                      </div>
                    </div>
                  </div>
                  <div className="mint-line-svg-wrapper">
                    <div className="mint-line-svg">
                      <div className="mint-line-svg-fill">
                        <div className="overlap-group-wrapper">
                          <div className="overlap-group-4">
                            <img className="group-4" alt="Group" src="/img/group-12846-2.png" />
                            <div className="text-wrapper-12">Meet the Visionaries</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-wrapper-13">
                    The revolutionary meme token, inspired by the legendary Satoshi Nakamoto! Embrace the spirit of
                    crypto innovation with SNMT, a community-driven token that combines humor and blockchain technology.
                    Bringing decentralization to the forefront, all in the name of Satoshi Nakamoto. Together, we are
                    rewriting the future of meme tokens and celebrating the genius behind the crypto revolution.
                  </p>
                </div>
              </div>
              <div className="frame-4">
                <div className="desktop">
                  <div className="overlap-8">
                    <div className="overlap-9">
                      <div className="overlap-10">
                        <div className="header-3">
                          <div className="div-header-container-2">
                            <div className="div-vertical-line-3" />
                            <div className="link-home-wrapper">
                              <div className="link-home-2">
                                <img className="yellow-3" alt="Yellow" src="/img/yellow-3.png" />
                                <div className="text-wrapper-14">Satoshi Tokens</div>
                              </div>
                            </div>
                            <div className="link-wrapper">
                              <div className="link-2">
                                <div className="before-6" />
                                <div className="before-9" />
                                <div className="after-10" />
                                <div className="div-btn-primary-5">
                                  <div className="before-10" />
                                  <div className="div-btn-primary-text-3">
                                    <div className="before-11" />
                                    <div className="BUY-snmt-NOW-5">BUY $SNMT NOW</div>
                                    <div className="after-11" />
                                  </div>
                                  <div className="after-12" />
                                </div>
                                <div className="after-13" />
                              </div>
                            </div>
                            <div className="div-vertical-line-4" />
                          </div>
                        </div>
                        <div className="text-wrapper-15">UNLEASH THE POWER OF</div>
                      </div>
                      <div className="coin-2">
                        <div className="group-5">
                          <div className="overlap-group-5">
                            <img className="ellipse-10" alt="Ellipse" src="/img/rectangle-1.png" />
                            <img className="ellipse-11" alt="Ellipse" src="/img/rectangle-1.png" />
                            <img className="ellipse-12" alt="Ellipse" src="/img/image.png" />
                            <img className="ellipse-13" alt="Ellipse" src="/img/rectangle-1.png" />
                            <img className="ellipse-14" alt="Ellipse" src="/img/rectangle-1.png" />
                          </div>
                        </div>
                        <img className="yellow-4" alt="Yellow" src="/img/yellow-3.png" />
                      </div>
                    </div>
                    <p className="text-wrapper-16">where every coin is a ticket to the moon! 🌕 Get ready to soar!</p>
                  </div>
                  <img className="SATOSHI-NAKAMOTO" alt="Satoshi NAKAMOTO" src="/img/rectangle-1.png" />
                  <div className="scroll-3">
                    <div className="bottom-left">
                      <div className="text-wrapper-9">KNOW MORE</div>
                      <div className="highlight">
                        <div className="heading">
                          <div className="details">
                            <div className="heading-2">
                              <div className="text-wrapper-17">About Us</div>
                            </div>
                            <img className="SVG-2" alt="Svg" src="/img/rectangle-1.png" />
                            <div className="line" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="bottom-right">
                      <div className="link">
                        <div className="scroll-2">
                          <div className="text">
                            <div className="text-wrapper-11">SCROLL</div>
                          </div>
                        </div>
                        <img className="button-2" alt="Button" src="/img/yellow-3.png" />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="desktop-2">
                  <div className="header-3">
                    <div className="div-header-container-2">
                      <div className="div-vertical-line-3" />
                      <div className="link-home-wrapper">
                        <div className="link-home-2">
                          <img className="yellow-5" alt="Yellow" src="/img/yellow-3.png" />
                          <div className="text-wrapper-14">Satoshi Tokens</div>
                        </div>
                      </div>
                      <div className="link-wrapper">
                        <div className="link-3">
                          <div className="before-6" />
                          <div className="before-9" />
                          <div className="after-14" />
                          <div className="div-btn-primary-5">
                            <div className="before-10" />
                            <div className="div-btn-primary-text-3">
                              <div className="before-11" />
                              <div className="BUY-snmt-NOW-6">BUY $SNMT NOW</div>
                              <div className="after-11" />
                            </div>
                            <div className="after-15" />
                          </div>
                          <div className="after-16" />
                        </div>
                      </div>
                      <div className="div-vertical-line-4" />
                    </div>
                  </div>
                  <div className="group-wrapper">
                    <div className="group-6">
                      <img className="SATOSHI-NAKAMOTO-2" alt="Satoshi NAKAMOTO" src="/img/rectangle-1.png" />
                      <div className="overlap-11">
                        <div className="left-text">
                          <div className="text-wrapper-18">UNLEASH THE POWER OF</div>
                          <p className="text-wrapper-19">
                            where every coin is a ticket to the moon! 🌕 Get ready to soar!
                          </p>
                        </div>
                        <div className="coin-3">
                          <div className="group-5">
                            <div className="overlap-group-6">
                              <img className="ellipse-10" alt="Ellipse" src="/img/rectangle-1.png" />
                              <img className="ellipse-11" alt="Ellipse" src="/img/rectangle-1.png" />
                              <img className="ellipse-12" alt="Ellipse" src="/img/image.png" />
                              <img className="ellipse-13" alt="Ellipse" src="/img/rectangle-1.png" />
                              <img className="ellipse-14" alt="Ellipse" src="/img/rectangle-1.png" />
                            </div>
                          </div>
                          <img className="yellow-6" alt="Yellow" src="/img/yellow-3.png" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="scroll-4">
                    <div className="bottom-left">
                      <div className="text-wrapper-9">KNOW MORE</div>
                      <div className="highlight">
                        <div className="heading">
                          <div className="details">
                            <div className="heading-2">
                              <div className="text-wrapper-17">About Us</div>
                            </div>
                            <img className="SVG-3" alt="Svg" src="/img/rectangle-1.png" />
                            <div className="line" />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="bottom-right">
                      <div className="link">
                        <div className="scroll-2">
                          <div className="text">
                            <div className="text-wrapper-11">SCROLL</div>
                          </div>
                        </div>
                        <img className="button-3" alt="Button" src="/img/yellow-3.png" />
                      </div>
                    </div>
                  </div>
                </div>
                <img className="final" alt="Final" src="/img/logo.jpg" />
                <div className="q-2">
                  <div className="div-5">
                    <img className="component-2" alt="Component" src="/img/rectangle-1.png" />
                    <div className="how-do-you-work-2">
                      <div className="text-wrapper-20">What are BRC-20 tokens?</div>
                    </div>
                  </div>
                  <div className="div-6" />
                  <p className="text-wrapper-21">
                    BRC-20 tokens are built on the Bitcoin Network using the ordinals protocol.
                  </p>
                </div>
                <div className="q-3">
                  <div className="div-5">
                    <img className="component-3" alt="Component" src="/img/rectangle-1.png" />
                    <div className="how-do-you-work-2">
                      <p className="text-wrapper-22">How do you buy BRC-20 tokens?</p>
                    </div>
                  </div>
                  <div className="div-6" />
                  <p className="text-wrapper-23">
                    Some popular BRC-20 tokens can be bought on centralized exchanges, while others – through
                    www.unisat.io
                  </p>
                </div>
                <div className="q-4">
                  <div className="div-5">
                    <img className="component-4" alt="Component" src="/img/rectangle-1.png" />
                    <div className="how-do-you-work-2">
                      <p className="text-wrapper-22">How are BRC-20 tokens created?</p>
                    </div>
                  </div>
                  <div className="div-6" />
                  <p className="text-wrapper-23">
                    These tokens are created using JavaScript Object Notion to make ordinal inscriptions on Satoshis,
                    thereby creating tokens with equal value.
                  </p>
                </div>
                <div className="q-5">
                  <div className="div-5">
                    <img className="component-5" alt="Component" src="/img/rectangle-1.png" />
                    <div className="how-do-you-work-3">
                      <p className="text-wrapper-24">What’s the difference between BRC-20 and ERC-20 tokens?</p>
                    </div>
                  </div>
                  <p className="text-wrapper-25">
                    The ERC-20 tokens are built on the Ethereum network and follow the ERC-20 token standard deployed
                    using smart contracts. On the other hand, BRC-20 tokens are built on the Bitcoin blockchain and
                    follow the BRC-20 token standard without the need for smart contracts.
                  </p>
                </div>
                <div className="div-7" />
                <div className="explore-webp" />
                <div className="hero-2">
                  <div className="group-6">
                    <img className="SATOSHI-NAKAMOTO-3" alt="Satoshi NAKAMOTO" src="/img/rectangle-1.png" />
                    <div className="overlap-11">
                      <div className="left-text">
                        <div className="text-wrapper-26">UNLEASH THE POWER OF</div>
                        <p className="text-wrapper-19">
                          where every coin is a ticket to the moon! 🌕 Get ready to soar!
                        </p>
                      </div>
                      <div className="coin-3">
                        <div className="group-5">
                          <div className="overlap-group-7">
                            <img className="ellipse-10" alt="Ellipse" src="/img/rectangle-1.png" />
                            <img className="ellipse-11" alt="Ellipse" src="/img/rectangle-1.png" />
                            <img className="ellipse-12" alt="Ellipse" src="/img/image.png" />
                            <img className="ellipse-13" alt="Ellipse" src="/img/rectangle-1.png" />
                            <img className="ellipse-14" alt="Ellipse" src="/img/rectangle-1.png" />
                          </div>
                        </div>
                        <img className="yellow-7" alt="Yellow" src="/img/yellow-3.png" />
                      </div>
                    </div>
                  </div>
                </div>
                <img className="logo" alt="Logo" src="/img/logo.jpg" />
                <div className="BUTTON-3">
                  <Button className="property-default" property1="default" />
                  <Button className="property-HOVER" property1="HOVER" />
                </div>
                <SocialIconsWrapper className="social-icons-instance" />
              </div>
              <img className="group-7" alt="Group" src="/img/group-13603-2.png" />
            </>
          )}
        </div>
        {screenWidth >= 1440 && (
          <>
            <div className="TECHNOLOGY">
              <div className="card">
                <div className="heading-wrapper">
                  <div className="heading-3">
                    <div className="text-wrapper-27">TECHNOLOGY</div>
                  </div>
                </div>
                <p className="text-wrapper-28">
                  Our tech is the heartbeat of the future! Satoshi Nakamoto Token is powered by cutting-edge BRC20
                  wizardry.
                </p>
              </div>
            </div>
            <div className="t-OKENOMICS">
              <div className="TOKENOMICS">
                <div className="overlap-12">
                  <div className="COIM">
                    <div className="coin-4">
                      <div className="overlap-13">
                        <div className="group-8">
                          <div className="overlap-group-8">
                            <img className="ellipse-15" alt="Ellipse" src="/img/rectangle-1-2x.png" />
                            <img className="ellipse-16" alt="Ellipse" src="/img/ellipse-1-1.png" />
                          </div>
                          <div className="overlap-14">
                            <img className="ellipse-17" alt="Ellipse" src="/img/ellipse-2-2.svg" />
                            <img className="ellipse-18" alt="Ellipse" src="/img/ellipse-6-2.svg" />
                            <img className="ellipse-19" alt="Ellipse" src="/img/ellipse-3-2.svg" />
                          </div>
                        </div>
                        <img className="yellow-8" alt="Yellow" src="/img/yellow-2.png" />
                      </div>
                    </div>
                  </div>
                  <img className="top" alt="Top" src="/img/top-2.png" />
                  <img className="down" alt="Down" src="/img/down.png" />
                  <img className="box" alt="Box" src="/img/box.svg" />
                  <div className="live">
                    <div className="overlap-15">
                      <div className="ellipse-20" />
                      <div className="text-wrapper-29">Tokenomics</div>
                      <img className="group-9" alt="Group" src="/img/group-13602-2.png" />
                    </div>
                  </div>
                  <p className="text-wrapper-30">
                    Commitment to a fairly minted ecosystem ensures that every participant has an equal opportunity to
                    engage in this groundbreaking tokenomic experience.
                  </p>
                  <div className="div-hero-info-right">
                    <div className="div-hero-feature">
                      <img className="img-2" alt="Img" src="/img/643550c922d6d3e0dcffd28b-ico-indicator-svg-2.svg" />
                      <div className="p-paragraph">
                        <div className="text-wrapper-31">Satoshi Nakamoto Token</div>
                      </div>
                      <div className="text-wrapper-32">Name</div>
                    </div>
                    <div className="div-hero-feature-2">
                      <img className="img-3" alt="Img" src="/img/643550c922d6d3e0dcffd28b-ico-indicator-svg-3.svg" />
                      <div className="p-paragraph-2">
                        <div className="text-wrapper-33">100,000,000 $SNMT</div>
                      </div>
                      <div className="text-wrapper-34">Token Supply</div>
                    </div>
                    <div className="div-hero-feature-3" />
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        <div
          className="about"
          style={{
            height: screenWidth < 1440 ? "412px" : screenWidth >= 1440 ? "304px" : undefined,
            left: screenWidth < 1440 ? "29px" : screenWidth >= 1440 ? "92px" : undefined,
            top: screenWidth < 1440 ? "814px" : screenWidth >= 1440 ? "4866px" : undefined,
            width: screenWidth < 1440 ? "382px" : screenWidth >= 1440 ? "1268px" : undefined,
          }}
        >
          {screenWidth < 1440 && (
            <>
              <div className="bottom-left-2">
                <div className="text-wrapper-9">KNOW MORE</div>
                <div className="highlight">
                  <div className="heading">
                    <div className="details-2">
                      <div className="heading-2">
                        <div className="text-wrapper-35">ABOUT US</div>
                      </div>
                      <img className="SVG-4" alt="Svg" src="/img/svg.svg" />
                      <div className="line-2" />
                    </div>
                  </div>
                </div>
              </div>
              <div className="mint-line-svg-2">
                <div className="overlap-group-9">
                  <img className="group-10" alt="Group" src="/img/group-12846.png" />
                  <div className="text-wrapper-36">Meet the Visionaries</div>
                </div>
                <p className="text-wrapper-37">
                  The revolutionary meme token, inspired by the legendary Satoshi Nakamoto! Embrace the spirit of crypto
                  innovation with SNMT, a community-driven token that combines humor and blockchain technology. Bringing
                  decentralization to the forefront, all in the name of Satoshi Nakamoto. Together, we are rewriting the
                  future of meme tokens and celebrating the genius behind the crypto revolution.
                </p>
              </div>
              <div className="bottom-right-2">
                <div className="link">
                  <div className="scroll-2">
                    <div className="text">
                      <div className="text-wrapper-11">SCROLL</div>
                    </div>
                  </div>
                  <img className="button" alt="Button" src="/img/button.svg" />
                </div>
              </div>
            </>
          )}

          {screenWidth >= 1440 && (
            <div className="overlap-16">
              <div className="TOKENOMICS-2">
                <div className="overlap-17">
                  <img className="top-2" alt="Top" src="/img/top-3.png" />
                  <img className="down-2" alt="Down" src="/img/down-1.png" />
                  <img className="box-2" alt="Box" src="/img/box-1.svg" />
                  <div className="live-2">
                    <div className="overlap-group-10">
                      <div className="ellipse-21" />
                      <div className="text-wrapper-38">Connect</div>
                      <img className="group-11" alt="Group" src="/img/group-13602-3.png" />
                    </div>
                  </div>
                  <div className="text-wrapper-39">Connect with us via:</div>
                </div>
              </div>
              <p className="connect-with-us-for">
                Connect with us for the latest updates and community engagement! Follow our social media channels, join
                the conversation on telegram and stay informed about upcoming events and developments. Your
                participation is key to our shared journey. Let&#39;s shape the future together!
              </p>
              <div className="div-col-xl">
                <div className="div-flex-wrap">
                  <img className="link-bg-twitter" alt="Link bg twitter" src="/img/link-bg-twitter-1.png" />
                  <img className="link-bg-telegram" alt="Link bg telegram" src="/img/link-bg-telegram-1.png" />
                </div>
              </div>
              <div className="div-form-block">
                <div className="form-email-form">
                  <div className="input">
                    <div className="text-wrapper-40">Enter Your e-mail</div>
                  </div>
                  <PropertyDefaultWrapper className="BUTTON-instance" property1="default" text="SUBCSCRIBBE" />
                </div>
              </div>
            </div>
          )}
        </div>
        <div
          className="t-OKENOMICS-2"
          style={{
            height: screenWidth < 1440 ? "357px" : screenWidth >= 1440 ? "1176px" : undefined,
            left: screenWidth < 1440 ? "16px" : screenWidth >= 1440 ? "150px" : undefined,
            top: screenWidth < 1440 ? "1282px" : screenWidth >= 1440 ? "2096px" : undefined,
            width: screenWidth < 1440 ? "385px" : screenWidth >= 1440 ? "1061px" : undefined,
          }}
        >
          {screenWidth < 1440 && (
            <div className="overlap-18">
              <img className="TOKENOMICS-3" alt="Tokenomics" src="/img/tokenomics.png" />
              <img className="top-3" alt="Top" src="/img/top.png" />
              <p className="text-wrapper-41">
                Commitment to a fairly minted ecosystem ensures that every participant has an equal opportunity to
                engage in this groundbreaking tokenomic experience.
              </p>
              <div className="live-3">
                <div className="overlap-group-11">
                  <div className="ellipse-22" />
                  <div className="text-wrapper-42">Tokenomics</div>
                  <img className="group-12" alt="Group" src="/img/group-13602.png" />
                </div>
              </div>
              <div className="div-hero-info-right-2">
                <div className="div-hero-feature">
                  <img className="img-4" alt="Img" src="/img/643550c922d6d3e0dcffd28b-ico-indicator-svg.svg" />
                  <div className="satoshi-nakamoto-wrapper">
                    <div className="satoshi-nakamoto">
                      Satoshi Nakamoto <br />
                      Token
                    </div>
                  </div>
                  <div className="text-wrapper-43">Name</div>
                </div>
                <div className="div-hero-feature-2">
                  <img className="img-5" alt="Img" src="/img/643550c922d6d3e0dcffd28b-ico-indicator-svg-1.svg" />
                  <div className="p-paragraph-3">
                    <div className="text-wrapper-44">100,000,000 $SNMT</div>
                  </div>
                  <div className="text-wrapper-45">Token Supply</div>
                </div>
                <div className="div-hero-feature-4" />
              </div>
            </div>
          )}

          {screenWidth >= 1440 && (
            <>
              <div className="div-row-margin">
                <div className="div-main-process">
                  <img className="img-6" alt="Chain blue mark svg" src="/img/chain-blue-mark-svg-2.svg" />
                  <div className="p-white-text">
                    <div className="text-wrapper-46">ROADMAP</div>
                  </div>
                  <img className="chain-blue-mark-svg" alt="Chain blue mark svg" src="/img/chain-blue-mark-svg-3.svg" />
                </div>
              </div>
              <div className="ROADMAP-CONTENT">
                <div className="overlap-19">
                  <div className="overlap-group-12">
                    <img
                      className="phase-genesis"
                      alt="Phase genesis"
                      src="/img/phase-1-genesis-building-foundations-q4-2023-q1-2024-deve.svg"
                    />
                    <img
                      className="phase-ignition"
                      alt="Phase ignition"
                      src="/img/phase-2-ignition-community-activation-q2-2024-launch-comm.svg"
                    />
                    <img className="mint-line-svg-3" alt="Mint line svg" src="/img/mint-line-svg-3.svg" />
                    <img className="mint-line-svg-4" alt="Mint line svg" src="/img/mint-line-svg-4.svg" />
                    <img className="mint-right-line-svg" alt="Mint right line svg" src="/img/mint-right-line-svg.svg" />
                  </div>
                  <img
                    className="phase-zenith-mass"
                    alt="Phase zenith mass"
                    src="/img/phase-3-zenith-mass-adoption-and-beyond-q3-2024-expand-u.svg"
                  />
                </div>
              </div>
            </>
          )}
        </div>
        <div
          className="overlap-20"
          style={{
            height: screenWidth < 1440 ? "357px" : screenWidth >= 1440 ? "558px" : undefined,
            left: screenWidth < 1440 ? "22px" : screenWidth >= 1440 ? "76px" : undefined,
            top: screenWidth < 1440 ? "4306px" : screenWidth >= 1440 ? "3400px" : undefined,
            width: screenWidth < 1440 ? "385px" : screenWidth >= 1440 ? "1300px" : undefined,
          }}
        >
          {screenWidth < 1440 && (
            <>
              <footer className="footer">
                <div className="t-OKENOMICS-3">
                  <div className="overlap-18">
                    <img className="TOKENOMICS-3" alt="Tokenomics" src="/img/tokenomics-1.png" />
                    <img className="top-3" alt="Top" src="/img/top-1.png" />
                    <div className="live-3">
                      <div className="overlap-group-11">
                        <div className="ellipse-23" />
                        <div className="text-wrapper-47">Connect</div>
                        <img className="group-12" alt="Group" src="/img/group-13602-1.png" />
                      </div>
                    </div>
                  </div>
                </div>
              </footer>
              <div className="text-wrapper-48">Connect with us via:</div>
              <div className="div-flex-wrap-wrapper">
                <div className="div-flex-wrap-2">
                  <img className="link-bg-twitter-2" alt="Link bg twitter" src="/img/link-bg-twitter-1.png" />
                  <img className="link-bg-telegram-2" alt="Link bg telegram" src="/img/link-bg-telegram-1.png" />
                </div>
              </div>
              <div className="form-email-form-wrapper">
                <div className="form-email-form-2">
                  <div className="input-2">
                    <div className="text-wrapper-49">Enter Your e-mail</div>
                  </div>
                  <div className="BUTTON-4">
                    <div className="overlap-21">
                      <div className="before-6" />
                      <div className="overlap-22">
                        <div className="before-12" />
                        <div className="before-13" />
                        <div className="div-btn-primary-6">
                          <div className="overlap-group-13">
                            <button className="subscribe-wrapper">
                              <div className="subscribe">SUBSCRIBE</div>
                            </button>
                            <div className="text-wrapper-50">↑</div>
                          </div>
                        </div>
                        <div className="after-17" />
                      </div>
                      <div className="after-18" />
                      <div className="after-19" />
                    </div>
                  </div>
                </div>
              </div>
              <p className="connect-with-us-for-2">
                Connect with us for the latest updates and community engagement! Follow our social media channels, join
                the conversation on telegram and stay informed about upcoming events and developments. Your
                participation is key to our shared journey. Let&#39;s shape the future together!
              </p>
            </>
          )}

          {screenWidth >= 1440 && (
            <div className="element">
              <div className="div-col-md">
                <div className="TEXT">
                  <div className="HOW-TO-BUY-SNMT-wrapper">
                    <img className="img-6" alt="How TO BUY SNMT" src="/img/how-to-buy-snmt-1.svg" />
                  </div>
                  <p className="text-wrapper-51">Purchase SNMT by navigating to a supported exchange.</p>
                </div>
                <div className="div-row">
                  <img className="div-8" alt="Div" src="/img/div-2.png" />
                  <img className="div-8" alt="Div" src="/img/div-1.png" />
                </div>
                <div className="text-wrapper-52">MORE COMING SOON...</div>
              </div>
            </div>
          )}
        </div>
        <div
          className="FAQ-s-interactive"
          style={{
            height: screenWidth >= 1440 ? "652px" : screenWidth < 1440 ? "231px" : undefined,
            left: screenWidth >= 1440 ? "86px" : screenWidth < 1440 ? "17px" : undefined,
            top: screenWidth >= 1440 ? "4086px" : screenWidth < 1440 ? "1695px" : undefined,
            width: screenWidth >= 1440 ? "1280px" : screenWidth < 1440 ? "327px" : undefined,
          }}
        >
          {screenWidth >= 1440 && (
            <>
              <div className="frequently-asked">FREQUENTLY ASKED QUESTIONS</div>
              <Link className="q-6" to="/q2">
                <div className="div-9">
                  <div className="text-wrapper-53">What are BRC-20 tokens?</div>
                  <img className="img-7" alt="Img" src="/img/61a8f3b83e808a031716e599-plus-svg-4.svg" />
                </div>
                <div className="div-10" />
              </Link>
              <Link className="q-7" to="/q3">
                <div className="div-5">
                  <p className="text-wrapper-54">How do you buy BRC-20 tokens?</p>
                  <img className="img-7" alt="Img" src="/img/61a8f3b83e808a031716e599-plus-svg-5.svg" />
                </div>
                <div className="div-10" />
              </Link>
              <Link className="q-8" to="/q4">
                <div className="div-5">
                  <p className="text-wrapper-55">How are BRC-20 tokens created?</p>
                  <img className="img-7" alt="Img" src="/img/61a8f3b83e808a031716e599-plus-svg-6.svg" />
                </div>
                <div className="div-10" />
              </Link>
              <Link className="q-9" to="/q5">
                <div className="div-5">
                  <p className="text-wrapper-56">What’s the difference between BRC-20 and ERC-20 tokens?</p>
                  <img className="img-7" alt="Img" src="/img/61a8f3b83e808a031716e599-plus-svg-7.svg" />
                </div>
                <div className="div-10" />
              </Link>
            </>
          )}

          {screenWidth < 1440 && (
            <>
              <div className="hero-card-bg-svg">
                <div className="overlap-group-14">
                  <img className="group-13" alt="Group" src="/img/group-12985.png" />
                  <div className="heading-4">
                    <div className="text-wrapper-57">TECHNOLOGY</div>
                  </div>
                </div>
              </div>
              <p className="text-wrapper-58">
                Our tech is the heartbeat of the future! Satoshi Nakamoto Token is powered by cutting-edge BRC20
                wizardry.
              </p>
            </>
          )}
        </div>
        {screenWidth >= 1440 && <p className="text-wrapper-59">© 2023 snmt.vip. All Right Reserved</p>}

        {screenWidth < 1440 && (
          <>
            <div className="how-to-use">
              <div className="div-main-process-wrapper">
                <div className="div-main-process">
                  <img className="chain-blue-mark-svg-2" alt="Chain blue mark svg" src="/img/chain-blue-mark-svg.svg" />
                  <div className="p-white-text-2">
                    <div className="text-wrapper-46">ROADMAP</div>
                  </div>
                  <img
                    className="chain-blue-mark-svg-3"
                    alt="Chain blue mark svg"
                    src="/img/chain-blue-mark-svg-1.svg"
                  />
                </div>
              </div>
              <div className="overlap-23">
                <img className="mint-line-svg-5" alt="Mint line svg" src="/img/mint-line-svg.svg" />
                <img className="mint-line-svg-6" alt="Mint line svg" src="/img/mint-line-svg-1.svg" />
                <p className="text-wrapper-60">Phase 1: Genesis - Building Foundations (Q4 2023-Q1 2024)</p>
                <p className="text-wrapper-61">Phase 2: Ignition - Community Activation (Q2 2024)</p>
                <p className="develop-and-launch">
                  {" "}
                  - Develop and launch the Satoshi Nakamoto Token with a transparent and fair distribution model. <br />
                  <br />
                  &nbsp;&nbsp; - Establish a robust and secure blockchain infrastructure to ensure the token&#39;s
                  stability.
                  <br /> <br />
                  &nbsp;&nbsp; - Begin community building through social media, forums, and partnerships.
                </p>
              </div>
              <div className="overlap-24">
                <img className="mint-line-svg-7" alt="Mint line svg" src="/img/mint-line-svg-2.svg" />
                <p className="text-wrapper-62">Phase 3 : Zenith - Mass Adoption and Beyond (Q3 2024)</p>
                <p className="launch-community">
                  - Launch community-driven initiatives, including contests, events, and collaborative projects. <br />
                  <br />
                  &nbsp;&nbsp; - Initiate strategic partnerships to expand the token&#39;s reach and use cases
                  <br />. <br />
                  &nbsp;&nbsp; - SNMT will be integrated to Unisat Swap, enhancing utility and accessibility in the
                  crypto ecosystem.
                  <br />
                  <br />
                  &nbsp;&nbsp; - The token aims to use cases in gaming and NFTs, fostering broader adoption and
                  engagement.
                </p>
              </div>
              <p className="expand-use-cases-by">
                - Expand use cases by targeting industries beyond traditional crypto sectors. <br />
                <br />
                &nbsp;&nbsp; - Develop partnerships with mainstream businesses to integrate Satoshi Nakamoto Token for
                everyday transactions. <br />
                <br />
                &nbsp;&nbsp; - Explore interoperability with other blockchains to enhance accessibility and user
                experience. <br />
                <br />
                &nbsp;&nbsp; - Engage the community through interactive campaigns, fueling widespread adoption. Making
                SNMT a cornerstone in the decentralized entertainment landscape
              </p>
            </div>
            <div className="how-to-use-2">
              <div className="TEXT-2">
                <div className="img-wrapper">
                  <img className="HOW-TO-BUY-SNMT" alt="How TO BUY SNMT" src="/img/how-to-buy-snmt.svg" />
                </div>
                <p className="text-wrapper-63">Purchase SNMT by navigating to a supported exchange.</p>
              </div>
              <div className="overlap-25">
                <div className="div-row-2">
                  <img className="div-11" alt="Div" src="/img/div-2.png" />
                  <img className="div-12" alt="Div" src="/img/div-1.png" />
                </div>
                <div className="text-wrapper-64">MORE COMING SOON...</div>
              </div>
            </div>
            <div className="faq">
              <div className="frequently-asked-2">FREQUENTLY ASKED QUESTIONS</div>
              <Link className="q-10" to="/q2">
                <div className="div-13">
                  <div className="text-wrapper-65">What are BRC-20 tokens?</div>
                  <img className="img-8" alt="Img" src="/img/61a8f3b83e808a031716e599-plus-svg.svg" />
                </div>
                <div className="div-14" />
              </Link>
              <Link className="q-11" to="/q3">
                <div className="div-15">
                  <p className="text-wrapper-66">How do you buy BRC-20 tokens?</p>
                  <img className="img-9" alt="Img" src="/img/61a8f3b83e808a031716e599-plus-svg-1.svg" />
                </div>
                <div className="div-14" />
              </Link>
              <Link className="q-12" to="/q4">
                <div className="div-15">
                  <p className="text-wrapper-67">How are BRC-20 tokens created?</p>
                  <img className="img-10" alt="Img" src="/img/61a8f3b83e808a031716e599-plus-svg-2.svg" />
                </div>
                <div className="div-14" />
              </Link>
              <Link className="q-13" to="/q5">
                <div className="div-15">
                  <p className="text-wrapper-68">What’s the difference between BRC-20 and ERC-20 tokens?</p>
                  <img className="img-9" alt="Img" src="/img/61a8f3b83e808a031716e599-plus-svg-3.svg" />
                </div>
                <div className="div-14" />
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
