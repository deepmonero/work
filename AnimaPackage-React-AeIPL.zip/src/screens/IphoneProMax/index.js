export { IphoneProMax } from "./IphoneProMax";
